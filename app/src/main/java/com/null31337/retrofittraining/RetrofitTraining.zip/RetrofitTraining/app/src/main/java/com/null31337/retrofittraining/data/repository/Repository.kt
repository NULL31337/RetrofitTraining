package com.null31337.retrofittraining.data.repository

class Repository {
}