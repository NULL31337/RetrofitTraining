package com.null31337.retrofittraining.data.api

object RetrofitInstance {
}