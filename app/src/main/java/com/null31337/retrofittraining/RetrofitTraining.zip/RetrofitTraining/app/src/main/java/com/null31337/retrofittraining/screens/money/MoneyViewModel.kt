package com.null31337.retrofittraining.screens.money

class MoneyViewModel {
}